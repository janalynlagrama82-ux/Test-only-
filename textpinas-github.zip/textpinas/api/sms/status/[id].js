// GET /api/sms/status/{id}
// Returns the delivery status of a message you sent.
const store = require("../../../lib/store");

module.exports = function handler(req, res) {
  if (req.method !== "GET") return res.status(405).json({ error: "method_not_allowed" });

  const id = req.query.id;
  const record = store.get(id);
  if (!record) {
    return res.status(404).json({ error: "not_found", message: "Unknown message id (store is in-memory; see README)." });
  }

  // In demo mode, simulate delivery progression from the queued timestamp.
  let status = record.status;
  const events = (record.events || []).slice();
  if (record.demo) {
    const elapsed = Date.now() - new Date(record.created_at).getTime();
    if (elapsed > 2500) status = "delivered";
    else if (elapsed > 1000) status = "sent";
    else status = "queued";
    const stages = ["queued", "sent", "delivered"];
    events.length = 0;
    for (const s of stages) {
      if (stages.indexOf(s) <= stages.indexOf(status)) {
        events.push({ status: s, at: new Date(new Date(record.created_at).getTime() + stages.indexOf(s) * 1200).toISOString() });
      }
    }
  }

  return res.status(200).json({
    id: record.id,
    status,
    to: record.to,
    from: record.from,
    segments: record.segments,
    provider: record.provider,
    demo: !!record.demo,
    events,
  });
};
