// POST /api/sms/send
// Sends one SMS through the configured provider.
// If SMS_API_KEY is not set, responds in DEMO mode (no real SMS is sent).
//
// Environment variables:
//   SMS_PROVIDER   semaphore | twilio | movider | vonage   (default: semaphore)
//   SMS_API_KEY    provider API key / token
//   SMS_SENDER_ID  sender name or number (provider-dependent)
//   Twilio only:   SMS_ACCOUNT_SID, SMS_AUTH_TOKEN
//   Vonage only:   SMS_API_KEY (key), SMS_API_SECRET

const store = require("../../lib/store");

const E164 = /^\+[1-9]\d{7,14}$/;

module.exports = async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") return res.status(405).json({ error: "method_not_allowed" });

  const body = typeof req.body === "string" ? safeParse(req.body) : (req.body || {});
  const to = (body.to || "").trim();
  const message = (body.message || "").trim();
  const from = (body.from || process.env.SMS_SENDER_ID || "TextPinas").trim();

  if (!E164.test(to)) {
    return res.status(400).json({ error: "invalid_number", message: "Use E.164 format, e.g. +639171234567" });
  }
  if (!message) {
    return res.status(400).json({ error: "invalid_request", message: "message is required" });
  }

  const provider = (process.env.SMS_PROVIDER || "semaphore").toLowerCase();
  const apiKey = process.env.SMS_API_KEY;

  // ---- DEMO MODE (no provider key configured) ----
  if (!apiKey) {
    const id = "demo_" + Math.random().toString(36).slice(2, 10);
    const record = {
      id,
      status: "queued",
      to,
      from,
      message,
      segments: countSegments(message),
      provider: "demo",
      demo: true,
      created_at: new Date().toISOString(),
      events: [{ status: "queued", at: new Date().toISOString() }],
    };
    store.save(record);
    return res.status(201).json({
      id: record.id,
      status: record.status,
      to: record.to,
      from: record.from,
      segments: record.segments,
      provider: "demo",
      demo: true,
      note: "Demo mode: no real SMS was sent. Set SMS_API_KEY to go live.",
      created_at: record.created_at,
    });
  }

  try {
    const result = await sendViaProvider(provider, { to, from, message, apiKey });
    const id = result.id || "msg_" + Math.random().toString(36).slice(2, 10);
    const record = {
      id,
      status: result.status || "queued",
      to,
      from,
      message,
      segments: countSegments(message),
      provider,
      created_at: new Date().toISOString(),
      events: [{ status: "queued", at: new Date().toISOString() }],
    };
    store.save(record);
    return res.status(201).json({
      id: record.id,
      status: record.status,
      to: record.to,
      from: record.from,
      segments: record.segments,
      provider,
      created_at: record.created_at,
    });
  } catch (err) {
    return res.status(502).json({ error: "provider_error", message: String(err && err.message ? err.message : err) });
  }
};

// ---- provider adapters ----
// NOTE: verify current endpoints/params against each provider's docs before production use.
async function sendViaProvider(provider, { to, from, message, apiKey }) {
  if (provider === "semaphore") {
    const r = await fetch("https://api.semaphore.co/api/v4/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ apikey: apiKey, number: to, message, sendername: from }),
    });
    if (!r.ok) throw new Error("semaphore " + r.status);
    const out = await r.json();
    const first = Array.isArray(out) ? out[0] : out;
    return { id: String(first && (first.message_id || first.id) || ""), status: "queued" };
  }

  if (provider === "twilio") {
    const sid = process.env.SMS_ACCOUNT_SID;
    const token = process.env.SMS_AUTH_TOKEN;
    if (!sid || !token) throw new Error("Twilio requires SMS_ACCOUNT_SID and SMS_AUTH_TOKEN");
    const params = new URLSearchParams({ To: to, From: from, Body: message });
    const r = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
      method: "POST",
      headers: {
        Authorization: "Basic " + Buffer.from(sid + ":" + token).toString("base64"),
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: params.toString(),
    });
    if (!r.ok) throw new Error("twilio " + r.status);
    const out = await r.json();
    return { id: out.sid, status: out.status || "queued" };
  }

  if (provider === "vonage") {
    const params = new URLSearchParams({
      api_key: apiKey,
      api_secret: process.env.SMS_API_SECRET || "",
      to: to.replace("+", ""),
      from,
      text: message,
    });
    const r = await fetch("https://rest.nexmo.com/sms/json", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: params.toString(),
    });
    if (!r.ok) throw new Error("vonage " + r.status);
    const out = await r.json();
    const msg = out.messages && out.messages[0];
    return { id: msg && msg["message-id"], status: "queued" };
  }

  if (provider === "movider") {
    const params = new URLSearchParams({ api_key: apiKey, api_secret: process.env.SMS_API_SECRET || "", to, text: message, from });
    const r = await fetch("https://api.movider.co/v1/sms", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: params.toString(),
    });
    if (!r.ok) throw new Error("movider " + r.status);
    const out = await r.json();
    return { id: String(out.message_id || ""), status: "queued" };
  }

  throw new Error("unknown provider: " + provider);
}

function safeParse(s) { try { return JSON.parse(s); } catch (e) { return {}; } }

function countSegments(text) {
  var gsm = /^[\x00-\x7F]*$/.test(text);
  var per = gsm ? 160 : 70;
  var perMulti = gsm ? 153 : 67;
  return text.length <= per ? 1 : Math.ceil(text.length / perMulti);
}
