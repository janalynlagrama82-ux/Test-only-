// GET /api/sms/messages?limit=20
// Lists recent messages (newest first). In-memory store — see README for production notes.
const store = require("../../lib/store");

module.exports = function handler(req, res) {
  if (req.method !== "GET") return res.status(405).json({ error: "method_not_allowed" });

  const limit = Math.min(parseInt(req.query.limit, 10) || 20, 100);
  const rows = store.list(limit).map((r) => ({
    id: r.id,
    to: r.to,
    from: r.from,
    status: r.status,
    provider: r.provider,
    demo: !!r.demo,
    created_at: r.created_at,
  }));

  return res.status(200).json({ data: rows, next_cursor: null });
};
