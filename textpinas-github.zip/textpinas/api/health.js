// GET /api/health
module.exports = function handler(req, res) {
  const provider = (process.env.SMS_PROVIDER || "semaphore").toLowerCase();
  const configured = Boolean(process.env.SMS_API_KEY);
  return res.status(200).json({
    status: "ok",
    provider,
    provider_configured: configured,
    mode: configured ? "live" : "demo",
    time: new Date().toISOString(),
  });
};
