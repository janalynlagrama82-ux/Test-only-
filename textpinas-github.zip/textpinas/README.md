# TextPinas

Send SMS to the Philippines (+63) and the rest of the world through a simple REST API, with a
beginner-friendly web composer and a step-by-step guide.

This repo is a **static site + Vercel Serverless Functions** project. It deploys to Vercel with
zero build step.

## What's inside

| Path | Purpose |
|------|---------|
| `index.html` | Landing page |
| `composer.html` | Interactive SMS composer (demo mode) |
| `api.html` | Full REST API reference |
| `guide.html` | Beginner's guide to sending international texts |
| `deploy.html` | Vercel deployment guide |
| `assets/styles.css`, `assets/app.js` | Shared styling and behaviour |
| `api/sms/send.js` | `POST /api/sms/send` — send one SMS |
| `api/sms/status/[id].js` | `GET /api/sms/status/{id}` — delivery status |
| `api/sms/messages.js` | `GET /api/sms/messages` — list recent messages |
| `api/health.js` | `GET /api/health` — service + provider status |
| `lib/store.js` | In-memory message store (demo only — see below) |

## Deploy to Vercel

### Option A — Dashboard (no CLI)

1. Create a free account at vercel.com.
2. **Add New → Project**.
3. Either drag-and-drop this folder, or push it to GitHub/GitLab and import the repo.
4. Click **Deploy**. You get a public URL like `https://textpinas.vercel.app`.

### Option B — CLI

```bash
npm i -g vercel
vercel          # preview
vercel --prod   # production
```

Follow the login prompt; the CLI prints the live URL when done.

## Environment variables

Set these in **Vercel → Project → Settings → Environment Variables**, then redeploy:

```
SMS_PROVIDER=semaphore        # or twilio / movider / vonage
SMS_API_KEY=your_provider_key
SMS_SENDER_ID=TextPinas
```

- Twilio also needs `SMS_ACCOUNT_SID` and `SMS_AUTH_TOKEN`.
- Vonage / Movider also need `SMS_API_SECRET`.

Without `SMS_API_KEY` the API runs in **demo mode** (no real SMS is sent) so you can test the
whole flow immediately.

## Run locally

```bash
npm i -g vercel
vercel dev
```

## API quick reference

```bash
curl -X POST http://localhost:3000/api/sms/send \
  -H "Content-Type: application/json" \
  -d '{"to":"+639171234567","from":"TextPinas","message":"Hello from TextPinas!"}'
```

See `api.html` for the full reference, error codes, and code samples.

## Important notes

- **SMS is not free.** Real delivery requires a paid gateway (Twilio, Semaphore, Movider, Vonage).
  Free trials are limited. There is no unlimited free international SMS.
- **The in-memory store is not durable.** Vercel serverless instances do not share memory, so
  `GET /api/sms/status/{id}` and `GET /api/sms/messages` may not see a message created by a
  different instance. For production, replace `lib/store.js` with a database (Vercel Postgres,
  Upstash Redis) or query your provider's message log. Provider adapters in `api/sms/send.js`
  should be verified against current provider docs.
- **Placeholders:** pricing, provider rates, sender-ID rules, contact details, and the
  Privacy/Terms/Acceptable-Use pages are drafts/placeholders and must be confirmed before launch.
- Never commit API keys. Keep them in environment variables only.
