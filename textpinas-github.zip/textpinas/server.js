// Minimal local dev server (no dependencies).
// Serves the static site and mounts the Vercel API handlers.
// Usage: node server.js   ->  http://localhost:3000
const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;

const apiRoutes = {
  "GET /api/health": require("./api/health"),
  "POST /api/sms/send": require("./api/sms/send"),
  "GET /api/sms/messages": require("./api/sms/messages"),
};
const statusHandler = require("./api/sms/status/[id].js");

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
};

const server = http.createServer((req, res) => {
  const url = new URL(req.url, "http://localhost");
  let pathname = decodeURIComponent(url.pathname);

  // ---- API ----
  if (pathname.startsWith("/api/")) {
    const key = req.method + " " + pathname;
    let handler = apiRoutes[key];
    const query = Object.fromEntries(url.searchParams.entries());

    if (!handler) {
      const m = pathname.match(/^\/api\/sms\/status\/(.+)$/);
      if (m && req.method === "GET") {
        handler = statusHandler;
        query.id = m[1];
      }
    }
    if (!handler) {
      res.writeHead(404, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ error: "not_found" }));
    }

    let raw = "";
    req.on("data", (c) => (raw += c));
    req.on("end", async () => {
      let body = {};
      try { body = raw ? JSON.parse(raw) : {}; } catch (e) { body = {}; }
      const mockRes = {
        _code: 200,
        _headers: {},
        setHeader(k, v) { this._headers[k] = v; },
        status(c) { this._code = c; return this; },
        json(b) {
          res.writeHead(this._code, Object.assign({ "Content-Type": "application/json" }, this._headers));
          return res.end(JSON.stringify(b));
        },
        end() { res.writeHead(this._code, this._headers); res.end(); },
      };
      try {
        await handler({ method: req.method, body, query, headers: req.headers }, mockRes);
      } catch (err) {
        res.writeHead(500, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ error: "server_error", message: String(err) }));
      }
    });
    return;
  }

  // ---- static ----
  if (pathname === "/") pathname = "/index.html";
  let file = path.join(ROOT, pathname);
  if (!file.startsWith(ROOT)) { res.writeHead(403); return res.end("Forbidden"); }
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    if (fs.existsSync(file + ".html")) file = file + ".html";
    else { res.writeHead(404, { "Content-Type": "text/plain" }); return res.end("Not found"); }
  }
  res.writeHead(200, { "Content-Type": MIME[path.extname(file)] || "application/octet-stream" });
  fs.createReadStream(file).pipe(res);
});

server.listen(PORT, () => console.log("TextPinas dev server on http://localhost:" + PORT));
