/* TextPinas — shared front-end behaviour (multi-page) */
(function () {
  "use strict";

  /* ---------- Mobile menu ---------- */
  var burger = document.getElementById("hamburger");
  var navlinks = document.getElementById("navlinks");
  if (burger && navlinks) {
    burger.addEventListener("click", function () {
      var open = navlinks.classList.toggle("open");
      burger.setAttribute("aria-expanded", open ? "true" : "false");
    });
  }

  /* ---------- Copy buttons ---------- */
  document.querySelectorAll(".copy").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var src = document.getElementById(btn.getAttribute("data-copy"));
      if (!src) return;
      var text = src.textContent;
      var done = function () {
        var old = btn.textContent;
        btn.textContent = "Copied!";
        setTimeout(function () { btn.textContent = old; }, 1400);
      };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(done, function () { fallback(text, done); });
      } else {
        fallback(text, done);
      }
    });
  });

  function fallback(text, done) {
    var ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand("copy"); done(); } catch (e) {}
    document.body.removeChild(ta);
  }

  /* ---------- Composer (only on composer.html) ---------- */
  var form = document.getElementById("composer-form");
  if (!form) return;

  var country = document.getElementById("country");
  var phone = document.getElementById("phone");
  var msg = document.getElementById("message");
  var e164Out = document.getElementById("e164-out");
  var validMark = document.getElementById("valid-mark");
  var charCount = document.getElementById("char-count");
  var segCount = document.getElementById("seg-count");
  var encHint = document.getElementById("encoding-hint");
  var reqCode = document.getElementById("req-code");
  var timeline = document.getElementById("timeline");
  var sendStatus = document.getElementById("send-status");
  var STORE = "textpinas-draft-v1";

  function digits(s) { return (s || "").replace(/[^\d]/g, ""); }

  function normalize() {
    var dial = country.options[country.selectedIndex].getAttribute("data-dial");
    var d = digits(phone.value);
    if (d.charAt(0) === "0") d = d.slice(1); // drop leading trunk zero
    if (dial === "63" && d.length === 10 && d.charAt(0) !== "63") d = "63" + d;
    if (!d) return "";
    return "+" + dial + d;
  }

  function validE164(v) { return /^\+[1-9]\d{7,14}$/.test(v); }

  function gsmSafe(text) {
    var extra = "€£¥èéùìòÇØøÅåΔ_ΦΓΛΩΠΨΣΘΞÆæßÉ¤¡ÄÖÑÜ§¿äöñüà^{}\\[~]|";
    for (var i = 0; i < text.length; i++) {
      var c = text.charAt(i);
      if (c.charCodeAt(0) < 128) continue;
      if (extra.indexOf(c) !== -1) continue;
      return false;
    }
    return true;
  }

  function updateCounts() {
    var text = msg.value || "";
    var len = text.length;
    var gsm = gsmSafe(text);
    var per = gsm ? 160 : 70;
    var perMulti = gsm ? 153 : 67;
    var segs = len === 0 ? 1 : (len <= per ? 1 : Math.ceil(len / perMulti));
    charCount.textContent = len + " character" + (len === 1 ? "" : "s");
    segCount.textContent = segs + " SMS segment" + (segs === 1 ? "" : "s");
    encHint.textContent = gsm
      ? "GSM-7 encoding (standard characters)."
      : "Unicode (UCS-2) encoding — emoji or special characters reduce the limit to 70 characters per segment.";
    encHint.style.color = gsm ? "" : "#8a6414";
  }

  function updateNumber() {
    var v = normalize();
    if (!v) { e164Out.textContent = "—"; validMark.textContent = ""; return; }
    e164Out.textContent = v;
    if (validE164(v)) {
      validMark.textContent = "✓ looks valid";
      validMark.style.color = "var(--ok)";
    } else {
      validMark.textContent = "✕ check the number";
      validMark.style.color = "#c0392b";
    }
  }

  function updateRequest() {
    var v = normalize() || "+639171234567";
    var body = { to: v, from: "TextPinas", message: msg.value || "Your message here" };
    reqCode.textContent =
      "POST /api/sms/send\nAuthorization: Bearer $SMS_API_KEY\nContent-Type: application/json\n\n" +
      JSON.stringify(body, null, 2);
  }

  function saveDraft() {
    try { localStorage.setItem(STORE, JSON.stringify({ c: country.value, p: phone.value, m: msg.value })); } catch (e) {}
  }
  function loadDraft() {
    try {
      var raw = localStorage.getItem(STORE);
      if (!raw) return;
      var d = JSON.parse(raw);
      if (d.c) country.value = d.c;
      if (d.p) phone.value = d.p;
      if (d.m) msg.value = d.m;
    } catch (e) {}
  }

  function resetTimeline() {
    timeline.querySelectorAll("li").forEach(function (li) { li.classList.remove("done"); });
  }
  function step(name) {
    var li = timeline.querySelector('[data-step="' + name + '"]');
    if (li) li.classList.add("done");
  }

  form.addEventListener("submit", function (ev) {
    ev.preventDefault();
    var v = normalize();
    if (!validE164(v)) {
      sendStatus.textContent = "Please enter a valid mobile number for the selected country.";
      sendStatus.style.color = "#c0392b";
      phone.focus();
      return;
    }
    if (!msg.value.trim()) {
      sendStatus.textContent = "Please type a message first.";
      sendStatus.style.color = "#c0392b";
      msg.focus();
      return;
    }
    resetTimeline();
    sendStatus.style.color = "";
    sendStatus.textContent = "Demo: sending to " + v + " …";
    step("queued");
    setTimeout(function () { step("sent"); sendStatus.textContent = "Demo: handed to carrier …"; }, 1000);
    setTimeout(function () {
      step("delivered");
      sendStatus.textContent = "Demo complete: delivered to " + v + ". (No real SMS was sent.)";
    }, 2600);
  });

  var clearBtn = document.getElementById("clear-btn");
  if (clearBtn) {
    clearBtn.addEventListener("click", function () {
      country.value = "PH";
      phone.value = "";
      msg.value = "";
      try { localStorage.removeItem(STORE); } catch (e) {}
      resetTimeline();
      sendStatus.textContent = "Nothing sent yet.";
      sendStatus.style.color = "";
      updateNumber(); updateCounts(); updateRequest();
    });
  }

  [country, phone, msg].forEach(function (el) {
    el.addEventListener("input", function () { updateNumber(); updateCounts(); updateRequest(); saveDraft(); });
    el.addEventListener("change", function () { updateNumber(); updateCounts(); updateRequest(); saveDraft(); });
  });

  loadDraft();
  updateNumber();
  updateCounts();
  updateRequest();
})();
